﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace datatypeConvert
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void hex2float_button1_Click(object sender, EventArgs e)
        {
            string hexString = input_textBox1.Text;
            uint uintnum = uint.Parse(hexString,System.Globalization.NumberStyles.AllowHexSpecifier);
            byte[] floatBytes = BitConverter.GetBytes(uintnum);/*以字节数组的形式返回指定 32 位有符号整数值。*/
            float floatnum = BitConverter.ToSingle(floatBytes,0);
            output_textBox2.Text = Convert.ToString(floatnum);
        }

        private void float2hex_button2_Click(object sender, EventArgs e)
        {
            byte[] byteArr = BitConverter.GetBytes(Convert.ToSingle(input_textBox1.Text));
            Array.Reverse(byteArr);
            output_textBox2.Text =BitConverter.ToString(byteArr);

        }

        private void hex2double_button3_Click(object sender, EventArgs e)
        {
            string hexString = input_textBox1.Text;
            ulong ulongnum = ulong.Parse(hexString, System.Globalization.NumberStyles.AllowHexSpecifier);/*最后不能有空格*/
            byte[] doubleBytes = BitConverter.GetBytes(ulongnum);/*以字节数组的形式返回指定 32 位有符号整数值。*/
            double doublenum = BitConverter.ToDouble(doubleBytes, 0);
            output_textBox2.Text = Convert.ToString(doublenum);
        }

        private void double2hex_button4_Click(object sender, EventArgs e)
        {
            byte[] byteArr = BitConverter.GetBytes(Convert.ToDouble(input_textBox1.Text));
            Array.Reverse(byteArr);
            output_textBox2.Text = BitConverter.ToString(byteArr);
        }
    }
}
